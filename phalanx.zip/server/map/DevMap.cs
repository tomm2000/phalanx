using System;
using System.Collections.Generic;
using System.Linq;
using Godot;

public static class DevMap {
  public static MapData GenerateMap(
    int width = 2,
    int height = 2,
    uint maxElevation = 4,
    uint minElevation = 1,
    int? seed = null
  ) {
    var tiles = new List<TileData>();

    var random = seed == null ? new Random() : new Random(seed.Value);

    for (int y = 0; y < height; y++) {
      for (int x = 0; x < width; x++) {
        var elevation = (uint)random.Next((int) minElevation, (int) maxElevation + 1);

        // uint elevation = 1;

        // uint elevation = (uint) x;

        tiles.Add(new TileData {
          coords = HexCoords.FromOffsetCoords(x, y),
          elevation = elevation
        });
      }
    }

    var map = new MapData(tiles);

    GD.Print("tiles generated: ", map.Tiles.Count());

    return map;
  }
}