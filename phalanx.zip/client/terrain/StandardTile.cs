using System;
using System.Threading.Tasks;
using Godot;
using Chickensoft.AutoInject;
using Chickensoft.Introspection;
using Tlib.Nodes;
using System.Collections.Generic;
using Tlib;
using System.Linq;
namespace Client.Terrain;

[Meta(typeof(IAutoConnect), typeof(IAutoNode))]
public partial class StandardTile : Node3D {
  public override void _Notification(int what) => this.Notify(what);
  public static readonly string ScenePath = "uid://clkgqxom5swiy";

  public static StandardTile Instantiate() {
    var scene = GD.Load<PackedScene>(ScenePath);
    return scene.Instantiate<StandardTile>();
  }

  [Node] private MeshInstance3D Mesh { get; set; } = default!;
  private SurfaceTool surfaceTool = new SurfaceTool();

  internal async Task GenerateMesh(
    TileData tile,
    IEnumerable<(HexDirection, TileData)> neighbors,
    float terrainScale = 1f
  ) {
    var position = tile.coords.GridToWorld3D(terrainScale);
    Position = position;

    surfaceTool.Clear();
    surfaceTool.Begin(Godot.Mesh.PrimitiveType.Triangles);
    
    var triangles = Meshes.CreateHexagonMesh(radius: terrainScale, Constants.TerrainMeshSubdivisions);

    foreach (var triangle in triangles) {
      var a = ProjectVertex(triangle.A, tile, terrainScale, neighbors);
      var b = ProjectVertex(triangle.B, tile, terrainScale, neighbors);
      var c = ProjectVertex(triangle.C, tile, terrainScale, neighbors);

      var uv_a = VertexToUV(a);
      var uv_b = VertexToUV(b);
      var uv_c = VertexToUV(c);

      var triangleNormal = (a - b).Cross(c - a).Normalized();
      // GD.Print(triangleNormal);
      // var triangleNormal = Vector3.Up;

      surfaceTool.SetNormal(triangleNormal);
      surfaceTool.SetUV(uv_a);
      surfaceTool.AddVertex(a);

      surfaceTool.SetNormal(triangleNormal);
      surfaceTool.SetUV(uv_b);
      surfaceTool.AddVertex(b);

      surfaceTool.SetNormal(triangleNormal);
      surfaceTool.SetUV(uv_c);
      surfaceTool.AddVertex(c);
    }

    // surfaceTool.GenerateNormals();

    Mesh.Mesh = surfaceTool.Commit();

    return;
  }

    private Vector2 VertexToUV(Vector3 vertex) {
    return new Vector2((vertex.X + 1) / 3, (vertex.Z + 1) / 3);
  }

  private Vector3 ProjectVertex(
    Vector3 vertex,
    TileData tile,
    float terrainScale,
    IEnumerable<(HexDirection, TileData)> neighbors
  ) {
    var totalContribution = 1.0f;
    var totalHeight = (float)tile.elevation;

    foreach (var (direction, neighbor) in neighbors) {
      var distance = vertex.DistanceToEdge(direction, terrainScale); // from 0 to radius+
      var contribution = 0f;

      if (distance <= 0.05 * terrainScale) {
        contribution = 1;

      } else {
        distance /= terrainScale; // from 0 to 2 (at opposite edge)

        contribution = 2 - distance; // from 2 (at edge) to 0 (at opposite edge), 1 at center
        contribution -= 2f; // from 1 (at edge) to -1 (at opposite edge), 0 at center

        contribution = Numerics.LogisticSmooth(contribution, 1f - Constants.SlopeSteepness) * 2;
      }

      totalContribution += contribution;
      totalHeight += neighbor.elevation * contribution;
    }

    var baseHeight = totalHeight / totalContribution;

    vertex.Y = baseHeight * Constants.HeightScale; // scale the height

    return vertex;
  }
  
}