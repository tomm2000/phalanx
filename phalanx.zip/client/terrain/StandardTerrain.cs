using System;
using System.Threading.Tasks;
using Godot;
using Chickensoft.AutoInject;
using Chickensoft.Introspection;
using Tlib.Nodes;
using ImGuiNET;

namespace Client.Terrain;

[Meta(typeof(IAutoConnect))]
public partial class StandardTerrain : Node3D {
  public override void _Notification(int what) => this.Notify(what);
  public static readonly string ScenePath = "uid://bgu2ycrayqu6s";

  [Node]
  private Node3D TileContainer { get; set; } = default!;

  public override void _Ready() {
    GenerateTerrain().ContinueWith(t => {
      if (t.IsFaulted) {
        GD.PrintErr("Error generating terrain: ", t.Exception);
      } else {
        GD.Print("Terrain generated successfully.");
      }
    });
  }

  public async Task GenerateTerrain() {

    TileContainer.QueueFreeChildren();

    var map = DevMap.GenerateMap(width: 20, height: 20, seed: 1);

    foreach (var tile in map.Tiles) {
      var neighbors = map.NeighborsWithDirections(tile.coords);

      // foreach (var (direction, neighbor) in neighbors) {
      //   GD.Print($"Neighbor: {tile.coords} Direction: {direction}, D: {(int)direction}");
      // }

      var tileInstance = StandardTile.Instantiate();
      TileContainer.AddChild(tileInstance);

      await tileInstance.GenerateMesh(tile, neighbors);
    }

    return;
  }

  public Task GenerateTerrain(TileData[] tiles) {
    throw new NotImplementedException();
  }

  public HexCoords GetCoords(Vector3 position) {
    throw new NotImplementedException();
  }

  public Vector3 GetPosition(HexCoords coords) {
    throw new NotImplementedException();
  }

  #region Debug UI
  public void DebugUI() {
    // ImGui.Begin("Terrain Module");
    // ImGui.Separator();

    // ImGui.End();
  }
  #endregion
}