using System.Text.Json;
using Godot;
using MessagePack;

[MessagePackObject]
public readonly struct TileData {
  [Key(0)] public readonly HexCoords coords { init; get; }
  [Key(1)] public readonly uint elevation { init; get; }

  public override string ToString() {
    return $"""
    TileData ------------
      Elevation: {elevation}
      Coords: {coords}
    """;
  }
}