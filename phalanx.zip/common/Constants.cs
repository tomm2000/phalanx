public static class Constants {
  // Terrain
  public const float TerrainScale = 1f;
  public const uint TerrainMeshSubdivisions = 2; // should be at least 2, otherwise not enough details
  public const float SlopeSteepness = .8f; // 0 to 1
  public const float HeightScale = .1f;
}