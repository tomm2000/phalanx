using System;
using System.Collections;
using System.Collections.Generic;

public class MapData {
  private Dictionary<HexCoords, TileData> tileDict = [];

  public MapData(IEnumerable<TileData> tiles) {
    foreach (var tile in tiles) {
      tileDict[tile.coords] = tile;
    }
  }

  public IEnumerable<TileData> Tiles => tileDict.Values;

  /// <summary>
  /// Get the tile at the given coordinates.
  /// Returns null if no tile is found at the coordinates.
  /// </summary>
  public TileData? GetTileAt(HexCoords coords) {
    if (tileDict.TryGetValue(coords, out var tile)) {
      return tile;
    } else {
      return null;
    }
  }

  /// <summary>
  /// Gets the tiles neighboring the given coordinates.
  /// Does <b>NOT</b> include unexisting tiles.
  /// </summary>
  public IEnumerable<TileData> Neighbors(HexCoords coords) {
    var neighborCoords = coords.Neighbors();

    foreach (var neighbor in neighborCoords) {
      var tile = GetTileAt(neighbor);

      if (tile != null) {
        yield return tile.Value;
      }
    }
  }

  /// <summary>
  /// Gets the tiles neighboring the given coordinates.
  /// Includes unexisting tiles as null.
  /// </summary>
  public IEnumerable<TileData?> NeighborsNullable(HexCoords coords) {
    var neighborCoords = coords.Neighbors();

    foreach (var neighbor in neighborCoords) {
      yield return GetTileAt(neighbor);
    }
  }

  /// <summary>
  /// Gets the tiles neighboring the given coordinates with their directions.
  /// Does <b>NOT</b> include unexisting tiles.
  /// </summary>
  public IEnumerable<(HexDirection, TileData)> NeighborsWithDirections(HexCoords coords) {
    var neighborCoords = coords.NeighborsWithDirections();

    foreach (var (direction, neighbor) in neighborCoords) {
      var tile = GetTileAt(neighbor);

      if (tile != null) {
        yield return (direction, tile.Value);
      }
    }
  }

  /// <summary>
  /// Gets the tiles neighboring the given coordinates with their directions.
  /// Includes unexisting tiles as null.
  /// </summary>
  public IEnumerable<(HexDirection, TileData?)> NeighborsWithDirectionsNullable(HexCoords coords) {
    var neighborCoords = coords.NeighborsWithDirections();

    foreach (var (direction, neighbor) in neighborCoords) {
      yield return (direction, GetTileAt(neighbor));
    }
  }
}