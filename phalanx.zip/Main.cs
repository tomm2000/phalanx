using Godot;
using System;
using Chickensoft.AutoInject;
using Chickensoft.Introspection;
using ImGuiNET;

[Meta(typeof(IAutoConnect))]
public partial class Main : Node {
  public override void _Notification(int what) => this.Notify(what);

  public override void _Process(double delta) {
    // ImGui.Begin("ImGui on Godot 4");
    // ImGui.Text("hello world");
    // ImGui.End();
  }
}
